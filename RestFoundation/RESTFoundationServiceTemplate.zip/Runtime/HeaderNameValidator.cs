﻿// <copyright>
// Dmitry Starosta, 2012-2013
// </copyright>
using System.Text.RegularExpressions;

namespace $safeprojectname$.Runtime
{
    internal static class HeaderNameValidator
    {
        public static bool IsValid(string headerName)
        {
            return headerName != null && !Regex.IsMatch(headerName, @"\s");
        }
    }
}
