﻿// <copyright>
// Dmitry Starosta, 2012-2013
// </copyright>
using System;

namespace $safeprojectname$.Runtime
{
    internal class UrlParameter
    {
        public static readonly UrlParameter Optional = new UrlParameter();

        private UrlParameter()
        {
        }

        public override string ToString()
        {
            return String.Empty;
        }
    }
}
