﻿using System;
using System.Web;
using $safeprojectname$.App_Start;

namespace $safeprojectname$
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            RestConfig.Initialize();
        }
    }
}
