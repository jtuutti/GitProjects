﻿using System.Diagnostics.CodeAnalysis;

namespace $safeprojectname$.ServiceProxy.OperationMetadata
{
    /// <summary>
    /// Represents the HTTPS metadata.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public sealed class HttpsMetadata
    {
        /// <summary>
        /// Gets or sets the port number.
        /// </summary>
        public int Port { get; set; }
    }
}