﻿// <copyright>
// Dmitry Starosta, 2012-2013
// </copyright>
using System;

namespace $safeprojectname$
{
    /// <summary>
    /// Represents a service contract method parameter attribute that indicates that the parameter
    /// is used to bind the resource for POST, PATCH and PUT HTTP methods. Only one resource parameter
    /// is allowed per a service method.
    /// </summary>
    [AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false, Inherited = false)]
    public sealed class ResourceAttribute : Attribute
    {
    }
}
