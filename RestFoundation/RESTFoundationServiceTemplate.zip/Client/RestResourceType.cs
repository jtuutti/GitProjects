﻿// <copyright>
// Dmitry Starosta, 2012-2013
// </copyright>
namespace $safeprojectname$.Client
{
    /// <summary>
    /// Describes a REST HTTP resource type.
    /// </summary>
    public enum RestResourceType
    {
        /// <summary>
        /// An object serialized as JSON.
        /// </summary>
        Json,

        /// <summary>
        /// An object serialized as XML.
        /// </summary>
        Xml
    }
}
