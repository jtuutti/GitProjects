﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("2.0.1.0")]
[assembly: AssemblyFileVersion("2.0.1.0")]
[assembly: AssemblyTitle("REST Foundation")]
[assembly: AssemblyDescription("REST Service Framework")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("REST Foundation")]
[assembly: AssemblyCopyright("Copyright © Dmitry Starosta 2012-2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: Guid("afa35ccc-3f07-4e8e-ae8c-72036701a11a")]
[assembly: NeutralResourcesLanguage("en-US")]
