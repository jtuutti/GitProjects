﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Sample REST Service")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("REST Foundation")]
[assembly: AssemblyCopyright("Copyright © 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("e58b1d0a-5601-42c7-84f8-bcb76c403a94")]
