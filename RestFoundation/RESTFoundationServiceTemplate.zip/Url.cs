﻿// <copyright>
// Dmitry Starosta, 2012-2013
// </copyright>
namespace $safeprojectname$
{
    /// <summary>
    /// Represents predefined strongly-typed URLs.
    /// </summary>
    public static class Url
    {
        /// <summary>
        /// Gets the root service URL.
        /// </summary>
        public const string Root = "";
    }
}
