﻿// <copyright>
// Dmitry Starosta, 2012-2013
// </copyright>
using System.Web;

namespace $safeprojectname$.UnitTesting
{
    internal sealed class TestHttpApplication : HttpApplication
    {
        public TestHttpApplication()
        {
            RestHttpModule.IsInitialized = true;
        }
    }
}
