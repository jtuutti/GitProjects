﻿// <copyright>
// Dmitry Starosta, 2012-2013
// </copyright>
using System;
using System.Web;

namespace $safeprojectname$.Context
{
    /// <summary>
    /// Defines a base service context class.
    /// This class cannot be instantiated.
    /// </summary>
    public abstract class ContextBase
    {
        /// <summary>
        /// Gets the underlying <see cref="HttpContextBase"/> instance.
        /// </summary>
        protected virtual HttpContextBase Context
        {
            get
            {
                HttpContext context = HttpContext.Current;

                if (context == null)
                {
                    throw new InvalidOperationException(RestResources.MissingHttpContext);
                }

                return new HttpContextWrapper(context);
            }
        }
    }
}
